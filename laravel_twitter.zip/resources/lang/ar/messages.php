<?php

return [

    // 'avatar max size' => 'لا تحاول',
    'Idenetity' => 'البريد الالكنروني أو رقم الهاتف',
    'Login' => 'تسجيل الدخول',
    'Password' => 'كلمة المرور',
    'Remember Me' => 'تذكرني',
    'Forgot Your Password?' => 'نسيت كلمة المرور؟',
    'Home' => 'الرئيسية',
    'Explore' => 'استكشف',
    'Notifications' => 'الإشعارات',
    'Profile' => 'الملف الشخصي',
    'Logout' => 'تسجيل الخروج',
    'Whats\'s up doc?' => 'كيف الحال؟',
    'Tweet' => 'تـغـريـد',
    'Following' => 'المتابَعون',
    'No Following Yet.' => 'ليس لديك أي متابَعين.',
    'Followers' => 'المتابِعون',
    'No Followers Yet.' => 'ليس لديك أي متابِعين.',
    'Unfollow' => 'ألغٍ المتابعة',
    'Follow' => 'تابِع',
    'Edit Profile' => 'تعديل الحساب',
    'Joined' => 'انضم',
    'Find People To Follow!' => 'ابحث عن عن أشخاص لتتابعهم!',
    'No Tweets Yet.' => 'ليس هناك أي تغريدات حتى الآن.',
    'Username' => 'الاسم المستعار',
    'Name' => 'اسم المستخدم',
    'E-Mail Address' => 'البريد الالكتروني',
    'Confirm Password' => 'تاكيد كلمة المرور',
    'Bio' => 'السيرة الذاتية',
    'Avatar' => 'الصورة الشخصية',
    'Submit' => 'تحديث البيانات',





];
