<?php

return [

    'Idenetity' => 'Email Or Mobile No.',
    'Login' => 'Login',
    'Password' => 'Password',
    'Remember Me' => 'Remember Me',
    'Forgot Your Password?' => 'Forgot Your Password?',
    'Home' => 'Home',
    'Explore' => 'Explore',
    'Notifications' => 'Notifications',
    'Profile' => 'Profile',
    'Logout' => 'Logout',
    'Whats\'s up doc?' => 'Whats\'s up doc?',
    'Tweet' => 'Tweet',
    'Following' => 'Following',
    'No Following Yet.' => 'No Following Yet.',
    'Followers' => 'Followers',
    'No Followers Yet.' => 'No Followers Yet.',
    'Unfollow' => 'Unfollow',
    'Follow' => 'Follow',
    'Edit Profile' => 'Edit Profile',
    'Joined' => 'Joined',
    'Find People To Follow!' => 'Find People To Follow!',
    'No Tweets Yet.' => 'No Tweets Yet.',
    'Username' => 'Username',
    'Name' => 'Name',
    'E-Mail Address' => 'E-Mail Address',
    'Confirm Password' => 'Confirm Password',
    'Bio' => 'Bio',
    'Avatar' => 'Avatar',
    'Submit' => 'Update Profile',
    
    
    
    
    
    
];
