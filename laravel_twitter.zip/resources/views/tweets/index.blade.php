<x-app>
    @include('_publish-tweet-panel')

    <div class="timeline">
        @include('_timeline')
    </div>
</x-app>