<div class="media p-2 border-bottom">
    <a href="<?php echo e(route('profile', $tweet->user)); ?>"class="text-decoration-none text-dark"> 
        
        <div class="rounded-circle mr-3 mt-3"
        style="width:40px; height:40px;background-image: url(<?php echo e($tweet->user->avatar); ?>);
        background-size: cover;">
            
        </div>
    </a>
    <div class="media-body">
        <div class="font-weight-bold">
            <a href="<?php echo e(route('profile', $tweet->user)); ?>"class="text-decoration-none text-dark"> 
                <?php echo e($tweet->user->name); ?>

            </a>
            <span class="small text-muted ml-1"> <?php echo e('@'. $tweet->user->username); ?></span>
            <div class="small text-muted "><?php echo e($tweet->tweetDate()); ?></div>

        </div>

        <div class="mt-2" style="word-break: break-all">
            <?php echo e($tweet->body); ?>

        </div>
        <div id="l-<?php echo e($tweet->id); ?>">
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.like-buttons','data' => ['tweet' => $tweet]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['tweet' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tweet)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/_tweet.blade.php ENDPATH**/ ?>