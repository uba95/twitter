 <?php $__env->slot('friends'); ?> 
    <?php echo $__env->make('_friends-list', ['fUser' => isset($user) ? $user : current_user()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php $__env->endSlot(); ?>
<?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/friends-box.blade.php ENDPATH**/ ?>