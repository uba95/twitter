 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>

        <div class="mb-5">
            <div class="card rounded-bg">
                <div class="card-header h4">
                    <i class="fas fa-bell"></i>
                    New Notifications
                </div>
                <div class="card-body p-0">
                    <ul class="list-unstyled m-0">
                        <?php echo $__env->make('notifications.new-notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
        </div>

        <div>
            <div class="card">
                <div class="card-header h4">
                    <i class="far fa-bell"></i>
                    Old Notifications
                </div>
                <div class="card-body p-0">
                    <ul class="list-unstyled m-0">
                        <?php echo $__env->make('notifications.old-notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
        </div>
        
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/notifications/index.blade.php ENDPATH**/ ?>