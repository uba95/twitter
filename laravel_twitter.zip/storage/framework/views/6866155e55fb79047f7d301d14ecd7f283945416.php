 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section>
        <main class="container mx-auto p-0" >
            <div class=" d-lg-flex justify-content-between">

                <?php if(auth()->check()): ?>
                    <div class="col col-xl-2 p-xl-0 d-none d-xl-flex">
                        <?php echo $__env->make('_sidebar-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>

                    <div class="col col-12 col-lg-8 col-xl-7 px-2 px-sm-0 px-lg-3
                    <?php echo e(auth()->check() ? '' : 'mx-auto'); ?> ">
                        <?php echo e($slot); ?>

                    </div>
                    
                <?php if(auth()->check()): ?>
                    <div class="col col-lg-4 col-xl-3 px-0 d-none d-lg-flex flex-column">

                        <?php if(Route::currentRouteName() === 'profile'): ?>

                            <?php echo e($friends); ?>

                        <?php else: ?>

                            <?php echo $__env->make('_friends-list', ['fUser' => current_user()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>

                        
                    </div>
                <?php endif; ?>
                <?php echo e($toast ?? ''); ?>

            </div>
        </main>
    </section>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/components/app.blade.php ENDPATH**/ ?>