<div class="mb-4 rounded-lg p-2" style="background-color:#cfeaf5">
    <h4 class="font-weight-bold mb-4"><?php echo e(__('messages.Following')); ?></h4>
    <ul class="list-unstyled">
        <?php $__empty_1 = true; $__currentLoopData = $fUser->follows->sortByDesc('created_at')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="mb-3">
                <div class="row align-items-center mx-0">
                    <a href="<?php echo e(route('profile', $user)); ?>"
                        class="text-decoration-none text-dark col-lg-2"> 
                        
                        
                        <div class="rounded-circle "
                        style="width:40px; height:40px;background-image: url(<?php echo e($user->avatar); ?>);
                        background-size: cover;">
                            
                        </div>            
                    </a>
                    <div class="col-lg-6">
                        <a href="<?php echo e(route('profile', $user)); ?>"
                        class="text-decoration-none text-dark "> 
                            <div class="small font-weight-bold"><?php echo e($user->name); ?></div>
                        </a>
                        <div class="small text-muted"> <?php echo e('@'. $user->username); ?></div>
                    </div>
                    <div class="col-lg-2 p-0">
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.follow-button','data' => ['user' => $user,'style' => 'width:calc(0.5vw + 70px);height:calc(0.1vw + 30px);font-size:0.8rem']]); ?>
<?php $component->withName('follow-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'style' => 'width:calc(0.5vw + 70px);height:calc(0.1vw + 30px);font-size:0.8rem']); ?>
                            <input type="hidden" class="style" style="width:calc(0.5vw + 70px);height:calc(0.1vw + 30px);font-size:0.8rem">
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>            
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
            <div class="text-muted"><?php echo e(__('messages.No Following Yet.')); ?></div>
    
        <?php endif; ?>
        </ul>
</div>

<div class="mb-4 rounded-lg p-2" style="background-color:#cfeaf5">
    <h4 class="font-weight-bold mb-4"><?php echo e(__('messages.Followers')); ?></h4>
    <ul class="list-unstyled">
        <?php $__empty_1 = true; $__currentLoopData = $fUser->followers->sortByDesc('created_at')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="mb-3">
                <div class="row">
                    <a href="<?php echo e(route('profile', $user)); ?>"
                        class="text-decoration-none text-dark col-lg-2"> 
                        
                        
                        <div class="rounded-circle mx-2"
                        style="width:40px; height:40px;background-image: url(<?php echo e($user->avatar); ?>);
                        background-size: cover;">
                            
                        </div>            

                    </a>
                    <div class="col-lg-6">
                        <a href="<?php echo e(route('profile', $user)); ?>"
                        class="text-decoration-none text-dark "> 
                            <div class="small font-weight-bold"><?php echo e($user->name); ?></div>
                        </a>
                        <div class="small text-muted"> <?php echo e('@'. $user->username); ?></div>
                    </div>
                    <div class="col-lg-2 p-0">
                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.follow-button','data' => ['user' => $user,'style' => 'width:calc(0.5vw + 70px);height:calc(0.1vw + 30px);font-size:0.8rem']]); ?>
<?php $component->withName('follow-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'style' => 'width:calc(0.5vw + 70px);height:calc(0.1vw + 30px);font-size:0.8rem']); ?>
                            <input type="hidden" class="style" style="width:calc(0.5vw + 70px);height:calc(0.1vw + 30px);font-size:0.8rem">
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>            
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
            <div class="text-muted"><?php echo e(__('messages.No Followers Yet.')); ?></div>
    
        <?php endif; ?>
        </ul>
</div>
<?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/components/_friends-list.blade.php ENDPATH**/ ?>