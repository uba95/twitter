 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('friends-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="">
        <div class="mb-5">
            <div class="card rounded-bg">
                <div class="card-header h4">
                    <i class="fas fa-bell"></i>
                    New Notifications
                </div>
                <div class="card-body p-0">
                    <ul class="list-unstyled m-0">
                        <?php $__empty_1 = true; $__currentLoopData = $new_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($notification): ?>
                                <li class="rounded-bg p-3 d-flex align-items-center
                                <?php echo e($loop->last ? '' :  'border-bottom border-light'); ?>" style="background:#ddd">
                                    <i class="fa fas fa-circle text-danger mr-2" style="font-size:10px"></i>
                                    <div class="flex-grow-1">
                                        <a href="/profiles/<?php echo e($notification->data['username']); ?>"
                                            class="text-decoration-none text-dark">
                                            <strong><?php echo e($notification->data['name']); ?></strong>
                                        </a>
                                        <?php echo e($notification->type === 'App\Notifications\FollowNotifacation' ? ' Started Following You' : ''); ?>

                                        <?php echo e($notification->type === 'App\Notifications\LikeNotifacation' ? 'Liked Your Tweet' : ''); ?>

                                    </div>
                                    <span class="small text-muted text-right"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                                </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="rounded-bg p-3">
                                    <div>There's No Any New Notifications</div>
                                </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div>
            <div class="card">
                <div class="card-header h4">
                    <i class="far fa-bell"></i>
                    Old Notifications
                </div>
                <div class="card-body p-0">
                    <ul class="list-unstyled m-0">
                        <?php $__empty_1 = true; $__currentLoopData = $old_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($notification): ?>
                                <li class="rounded-bg p-3 d-flex align-items-center
                                <?php echo e($loop->last ? '' :  'border-bottom'); ?>">
                                    <div class="flex-grow-1">
                                        <a href="/profiles/<?php echo e($notification->data['username']); ?>"
                                            class="text-decoration-none text-dark">
                                            <strong><?php echo e($notification->data['name']); ?></strong>
                                        </a>
                                        <?php echo e($notification->type === 'App\Notifications\FollowNotifacation' ? ' Started Following You' : ''); ?>

                                        <?php echo e($notification->type === 'App\Notifications\LikeNotifacation' ? 'Liked Your Tweet' : ''); ?>

                                    </div>
                                    <span class="small text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                                </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="rounded-bg p-3">
                                    <div>There's No Notifications</div>
                                </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>    
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/notifications.blade.php ENDPATH**/ ?>