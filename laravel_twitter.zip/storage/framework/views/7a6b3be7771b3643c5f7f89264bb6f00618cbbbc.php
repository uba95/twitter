<?php if(auth()->check()): ?>
    <?php if (! (current_user()->is($user))): ?>

    
    
    <form data-user="<?php echo e($user->username); ?>" action="<?php echo e(localRoute(route('follow', $user->username))); ?>"
        class="follow" >
        <?php echo csrf_field(); ?>
        <?php echo e($slot?? ''); ?>

        <button type="submit" 

        class="btn rounded-pill text-white mb-sm-0 p-0 fb
        <?php echo e(current_user()->isFollowing($user) ?
        'btn-danger':
        'btn-primary'); ?>

        <?php echo e($myClass ?? ''); ?>

        "
        style="<?php echo e($style ?? 'width:calc(1.5vw + 70px);height:calc(0.8vw + 30px);font-size:0.9rem'); ?>"
        >
            <?php echo e(current_user()->isFollowing($user) ?
             __('messages.Unfollow') :
             __('messages.Follow')); ?>

        </button>
    </form>
    
    <?php endif; ?>
    <?php else: ?>
    <a href="/login" class="btn btn-primary btn-lg">Follow</a>
<?php endif; ?>

 <?php $__env->slot('toast'); ?> 
    <div class="toasts" style="position: fixed; bottom: -80px; right: 10px;z-index:99">
        <div class="toast bg-dark" role="alert" aria-live="assertive" aria-atomic="true" data-delay="3000">
            <div class="toast-header">
                <strong class="mr-auto">Twitter</strong>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body text-light">        
            <span class="msg">You Started Following</span><strong class="username">username</strong>
            </div>
        </div>    
    </div>
 <?php $__env->endSlot(); ?><?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/components/follow-button.blade.php ENDPATH**/ ?>