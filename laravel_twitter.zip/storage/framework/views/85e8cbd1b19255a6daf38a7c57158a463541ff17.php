 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<h3 class="mb-3"><?php echo e(__('messages.Find People To Follow!')); ?></h3>
<div class="border border-bottom-0 mb-5">
    <div class="infinite-scroll">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row m-0 py-2 px-0 px-sm-2 align-items-center border-bottom">

                <div class="col-8 col-sm-6">

                    <div class="row align-items-center">
                        <a href="<?php echo e(route('profile', $user->username)); ?>" class="col-3 mr-2 mr-md-0 text-decoration-none text-body">
                            
                            <div class="rounded-circle "
                            style="width:60px; height:60px;background-image: url(<?php echo e($user->avatar); ?>);
                            background-size: cover;">
                                
                            </div>                
                        </a>

                        <div class="col-8">
                            <a href="<?php echo e(route('profile', $user->username)); ?>" class="text-decoration-none text-body">
                                <h5 class="m-0"><?php echo e($user->name); ?></h5>
                            </a>
                            <div class="text-muted"><?php echo e('@' . $user->username); ?></div>
                        </div>

                    </div>

                </div>

                <div class="col-4 col-sm-5">
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.follow-button','data' => ['user' => $user]]); ?>
<?php $component->withName('follow-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($users->links()); ?>

    </div>
</div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 




<?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/explore.blade.php ENDPATH**/ ?>