 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
     <?php $__env->slot('friends'); ?> 
        <?php echo $__env->make('_friends-list', ['fUser' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>
        
    <header class="mb-3">
            
        <div class="position-relative">
            <div class="rounded-lg" style="height: calc(9vw + 80px);
            background-image: url(<?php echo e($user->cover); ?>);background-size: cover;background-position: center">
                
            </div>


            <?php if(current_user()->is($user)): ?>
                <form action="<?php echo e(route('profile', current_user())); ?>/cover" method="POST" enctype="multipart/form-data"
                class="position-absolute" style="top:1%; right:1%">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <i class="fas fa-image h3 m-0 text-secondary" style="color:#eee"></i>
                    <input type="file" class="position-absolute cover" name="cover"
                    style="width:30px;height:25px;top:0; right:0;opacity:0;font-size: 0;cursor: pointer;"
                    z-index="2" data-toggle="tooltip" data-placement="bottom" title="Change Cover">
                    <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php
                            function alert($msg) { echo "<script type='text/javascript'>alert('Error :  $msg');</script>"; }
                            alert($message);
                        ?>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>
                <script type="text/javascript">
                    $('.cover').change(function () { $(this).parent().submit(); });
                </script>
            <?php endif; ?>        


            <div class="rounded-circle position-absolute border"
            style="width:calc(6vw + 45px); height:calc(6vw + 45px); left:50%; bottom:0;
            transform: translateX(-50%) translateY(50%);background-image: url(<?php echo e($user->avatar); ?>);
            background-size: cover;border-color:#107cd8!important">
                
            </div>

            
        </div>
        
        <div class="d-flex align-items-center justify-content-between mt-2 mt-sm-2">

            <div>
                
                <div class="small text-muted"><?php echo e(__('messages.Joined')); ?> <?php echo e($user->created_at->diffForHumans()); ?></div>
            </div>

            <div class="">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $user)): ?>
                <a href="<?php echo e(route('profile', current_user())); ?>/edit" class="btn btn-outline-primary rounded-pill p-sm-2 mb-sm-0">
                    <?php echo e(__('messages.Edit Profile')); ?>

                </a>
            <?php endif; ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.follow-button','data' => ['user' => $user]]); ?>
<?php $component->withName('follow-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>

        </div>
        <h4 class="font-weight-bold mb-0 mt-md-3 text-center"><?php echo e($user->name); ?></h4>
        <div class=" text-muted text-center"><?php echo e('@' . $user->username); ?></div>
        <div class=" mb-4 mt-2 mt-lg-3 mt-xl-4 p-2 rounded-lg" style="background-color:#cfeaf5">
            <?php echo e($user->bio); ?>

        </div>
    
    </header>
    
        
        <?php echo $__env->make('_timeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/profiles/show.blade.php ENDPATH**/ ?>