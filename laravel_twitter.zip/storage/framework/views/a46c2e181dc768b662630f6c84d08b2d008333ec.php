<?php $__empty_1 = true; $__currentLoopData = $old_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if($notification): ?>
        <li class="rounded-bg p-3 d-flex align-items-center
        <?php echo e($loop->last ? '' :  'border-bottom'); ?>">
            <div class="flex-grow-1">
                <a href="/profiles/<?php echo e($notification->data['username']); ?>"
                    class="text-decoration-none text-dark">
                    <strong><?php echo e($notification->data['name']); ?></strong>
                </a>
                <?php echo e($notification->type === 'App\Notifications\FollowNotifacation' ? ' Started Following You' : ''); ?>

                <?php echo e($notification->type === 'App\Notifications\LikeNotifacation' ? 'Liked Your Tweet' : ''); ?>

            </div>
            <span class="small text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></span>
        </li>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <li class="rounded-bg p-3">
            <div>There's No Notifications</div>
        </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/notifications/old-notifications.blade.php ENDPATH**/ ?>