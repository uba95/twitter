<ul class="list-unstyled d-none d-xl-block rounded-lg p-lg-2 w-100"
style="background-color:#cfeaf5; height: fit-content;}">
    <li><a href="/home" class="font-weight-bold h6 mb-4 mt-2 text-decoration-none text-body d-block">
        <i class="fas fa-home fa-fw mr-1"></i>
        <?php echo e(__('messages.Home')); ?></a></li>
    <li><a href="/explore" class="font-weight-bold h6 mb-4 text-decoration-none text-body d-block">
        <i class="fas fa-hashtag fa-fw mr-1"></i>
        <?php echo e(__('messages.Explore')); ?></a></li>
    <li><a href="/notifications" class=" font-weight-bold h6 mb-4 text-decoration-none text-body d-block">
        <i class="fas fa-bell fa-fw mr-1"></i>
        <?php echo e(__('messages.Notifications')); ?>


        <span class="badge badge-danger ml-1 not_count" data-count="<?php echo e(current_user()->id); ?>"><?php echo e(current_user()->unreadNotifications->count()); ?></span>
        <script>$('ul li .not_count').text() == 0 ? $('ul li .not_count').hide() :  ''</script>
    </a></li>
    <li>
        <a href="<?php echo e(route('profile', auth()->user())); ?>" class="font-weight-bold h6 mb-4 text-decoration-none text-body d-block">
            <i class="fas fa-user fa-fw mr-1"></i>
            <?php echo e(__('messages.Profile')); ?></a></li>

    <div class="dropdown-divider" style="border-color:#999;"></div>

    <li>
        <form action="<?php echo e(localRoute('/logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn p-0 font-weight-bold mb-4 text-decoration-none text-body" style="font-size: 1rem">
                <i class="fas fa-sign-out-alt fa-fw mr-1"></i>
                <?php echo e(__('messages.Logout')); ?></button>
        </form>
    </li>

</ul>

<ul class="navbar-nav mr-auto d-xl-none px-2">
    <li class="nav-item"><a href="/home" class=" nav-link mb-1 text-decoration-none text-dark">
        <i class="fas fa-home fa-fw mr-1"></i>
        <?php echo e(__('messages.Home')); ?></a></li>
    <li class="nav-item"><a href="/explore" class=" nav-link mb-1 text-decoration-none text-dark">
        <i class="fas fa-hashtag fa-fw mr-1"></i>
        <?php echo e(__('messages.Explore')); ?></a></li>
    <li class="nav-item"><a href="/notifications" class=" nav-link mb-1 text-decoration-none text-dark">
        <i class="fas fa-bell fa-fw mr-1"></i>
        <?php echo e(__('messages.Notifications')); ?>


        <span class="badge badge-danger ml-1 not_count" data-count="<?php echo e(current_user()->id); ?>"><?php echo e(current_user()->unreadNotifications->count()); ?></span>
        <script>$('ul li .not_count').text() == 0 ? $('ul li .not_count').hide() :  ''</script>
        </a></li>
    <li class="nav-item"><a href="<?php echo e(route('profile', auth()->user())); ?>" class=" nav-link mb-1 text-decoration-none text-dark">
        <i class="fas fa-user fa-fw mr-1"></i>
        <?php echo e(__('messages.Profile')); ?></a></li>
    
    <div class="dropdown-divider" style="border-color:#999;"></div>

    <li class="nav-item">
        <form action="<?php echo e(localRoute('/logout')); ?> " method="POST" class="nav-link">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn p-0 mb-1 text-decoration-none text-dark">
                <i class="fas fa-sign-out-alt fa-fw mr-1"></i>
                <?php echo e(__('messages.Logout')); ?></button>
        </form>
    </li>
    
</ul><?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/_sidebar-links.blade.php ENDPATH**/ ?>