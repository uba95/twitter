<div class="border border-bottom-0 mb-5">

<div class="infinite-scroll">

        <?php $__empty_1 = true; $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php echo $__env->make('_tweet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="text-muted p-2"><?php echo e(__('messages.No Tweets Yet.')); ?></div>

        <?php endif; ?>

        <?php echo e($tweets->links()); ?>

</div>
</div>
<script>
    $(document).ready(function () {        
    $('ul.pagination').hide();
    $(function() {
        $('.infinite-scroll').jscroll({
            autoTrigger: true,
            loadingHtml: '<div class="text-center mt-5"><div class="spinner-grow text-primary" role="status"><span class="sr-only">Loading...</span></div></div>',
            padding: 0,
            nextSelector: '.pagination li.active + li a',
            contentSelector: 'div.infinite-scroll',
            callback: function() {
                $('ul.pagination').remove();
            }
        });
    });
    });
</script><?php /**PATH C:\xampp\htdocs\laravel_twitter\resources\views/_timeline.blade.php ENDPATH**/ ?>